# COMP2140 Assignment 2 — React + PostgREST App

This project is a small full-stack web application built with **React (Vite)** on the frontend and **PostgREST + PostgreSQL** on the backend.  
It demonstrates how to manage interview data (questions, applicants, and interviews) through a REST API connected to a relational database.  
The UI is styled with **Bootstrap 5** for responsive and simple layouts.

---

## ✨ Features
- **Applicants Page** — create and display applicant information  
- **Questions Page** — manage interview questions (add, edit, list)  
- **Interviews Page** — link applicants to questions and record interview results  
- **JWT Authentication** — secure API access  
- **Responsive UI** — styled with Bootstrap  
- **Same-Origin Deployment** — frontend and API are served together to avoid CORS/SSO issues  

---

## 🛠 Tech Stack
- **Frontend**: React 18 + Vite + Bootstrap 5  
- **Backend**: PostgreSQL + PostgREST  
- **Server**: Nginx reverse proxy (serves React build + proxies `/api/*` to PostgREST)  

---

## Running Locally

### 1. Install dependencies
```bash
npm install
2. Backend setup

Ensure PostgreSQL + PostgREST are running.

PostgREST should expose the tables: question, applicant, and interviews.

3. Start development server
npm run dev


Then visit http://localhost:5173
 in your browser.

📦 Build & Deployment
1. Build frontend
npm run build


This creates the production-ready files in the dist/ folder.

2. Example Nginx config (same-origin)
server {
  listen 80;
  server_name comp2140a2.uqcloud.net;

  root /var/www/app/dist;
  index index.html;

  location /api/ {
    proxy_pass http://127.0.0.1:3000/;   # PostgREST backend
    proxy_set_header Authorization $http_authorization;
  }

  location / {
    try_files $uri /index.html;
  }
}


This setup serves both the React frontend and the PostgREST API from the same domain.

🔑 API Examples
Create a question
POST /api/question
Content-Type: application/json
Authorization: Bearer <JWT>

{ "prompt": "Why do you want this role?" }

List applicants
GET /api/applicant?select=*
Authorization: Bearer <JWT>

⚠️ Troubleshooting

400 Bad Request
→ Check JSON keys match database column names and required fields are included.

302 Redirect to /login
→ You are hitting UQCloud SSO. Use same-origin deployment or local proxy.

CORS errors
→ Always use relative paths (/api/...) rather than cross-origin full URLs.

Have no idea on AI and Audio transcription, because there are always some bug on achieveing these two parts. So just used placeholder.
AI tools: https://chatgpt.com/share/68d53fed-b180-800f-adb3-4075c3c7a8a8