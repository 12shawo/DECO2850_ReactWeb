import { Routes, Route, Navigate } from 'react-router-dom'
import Header from './components/Header.jsx'
import Footer from './components/Footer.jsx'
import InterviewsPage from './pages/Interviews.jsx'
import QuestionsPage from './pages/Questions.jsx'
import ApplicantsPage from './pages/Applicants.jsx'
import TakeInterviewPage from './pages/TakeInterview.jsx'

export default function App(){
  return (
    <div className="d-flex flex-column min-vh-100">
      <Header />
      <main className="flex-grow-1">
        <Routes>
          <Route path="/" element={<Navigate to="/interviews" replace />} />
          <Route path="/interviews" element={<InterviewsPage />} />
          <Route path="/questions" element={<QuestionsPage />} />
          <Route path="/applicants" element={<ApplicantsPage />} />
          <Route path="/take" element={<TakeInterviewPage />} />
          <Route path="*" element={<div className="container py-4"><h4>Not Found</h4></div>} />
        </Routes>
      </main>
      <Footer />
    </div>
  )
}
