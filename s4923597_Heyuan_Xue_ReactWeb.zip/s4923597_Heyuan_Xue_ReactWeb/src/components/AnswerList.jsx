export default function AnswerList({ answers, questionsMap }){
    if(!answers?.length) return <div className="alert alert-secondary">No answers yet.</div>
    return (
      <ul className="list-group">
        {answers.map(a=>(
          <li key={a.id||`${a.question_id}-${a.created_at}`} className="list-group-item">
            <div className="fw-semibold">Q: {questionsMap.get(a.question_id) || a.question_id}</div>
            <div className="mt-1">A: {a.answer_text}</div>
            <div className="text-muted small mt-1">{a.created_at}</div>
          </li>
        ))}
      </ul>
    )
  }
  