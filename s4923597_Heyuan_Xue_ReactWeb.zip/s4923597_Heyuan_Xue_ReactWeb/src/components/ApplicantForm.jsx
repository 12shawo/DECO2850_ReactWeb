import { useEffect, useState } from 'react'

export default function ApplicantForm({ onSubmit, initial, interviewId, setInterviewId }){
  const [title, setTitle] = useState('')
  const [firstName, setFirstName] = useState('')
  const [surname, setSurname] = useState('')
  const [phone, setPhone] = useState('')
  const [email, setEmail] = useState('')
  const [status, setStatus] = useState('Not Started')

  useEffect(()=>{
    setTitle(initial?.title || '')
    setFirstName(initial?.firstname || initial?.first_name || '')
    setSurname(initial?.surname || '')
    setPhone(initial?.phone_number || initial?.phone || '')
    setEmail(initial?.email_address || initial?.email || '')
    setStatus(initial?.interview_status || 'Not Started')
  }, [initial])

  const submit = (e)=>{
    e.preventDefault()
    if (!interviewId) return alert('Please set Interview ID first.')
    if(!title||!firstName||!surname||!phone||!email) return alert('All fields are required.')
    onSubmit({
      title,
      firstname: firstName,   // 映射到后端字段
      surname,
      phone_number: phone,
      email_address: email,
      interview_status: status,
      interview_id: Number(interviewId),
    })
    if(!initial){
      setTitle(''); setFirstName(''); setSurname(''); setPhone(''); setEmail(''); setStatus('Not Started')
    }
  }

  return (
    <form onSubmit={submit} className="card card-body mb-3">
      <div className="row g-3">
        <div className="col-md-3">
          <label className="form-label">Interview ID*</label>
          <input
            className="form-control"
            value={interviewId ?? ''}
            onChange={e=>setInterviewId(e.target.value)}
            placeholder="e.g. 1"
          />
        </div>
        <div className="col-md-3">
          <label className="form-label">Title*</label>
          <input className="form-control" value={title} onChange={e=>setTitle(e.target.value)} placeholder="Mr/Ms/Dr" />
        </div>
        <div className="col-md-3">
          <label className="form-label">First name*</label>
          <input className="form-control" value={firstName} onChange={e=>setFirstName(e.target.value)} />
        </div>
        <div className="col-md-3">
          <label className="form-label">Surname*</label>
          <input className="form-control" value={surname} onChange={e=>setSurname(e.target.value)} />
        </div>
        <div className="col-md-4">
          <label className="form-label">Phone*</label>
          <input className="form-control" value={phone} onChange={e=>setPhone(e.target.value)} />
        </div>
        <div className="col-md-5">
          <label className="form-label">Email*</label>
          <input type="email" className="form-control" value={email} onChange={e=>setEmail(e.target.value)} />
        </div>
        <div className="col-md-3">
          <label className="form-label">Interview Status*</label>
          <select className="form-select" value={status} onChange={e=>setStatus(e.target.value)}>
            <option>Not Started</option>
            <option>Completed</option>
          </select>
        </div>
        <div className="col-12">
          <button className="btn btn-primary">{initial ? 'Update' : 'Add'}</button>
        </div>
      </div>
    </form>
  )
}
