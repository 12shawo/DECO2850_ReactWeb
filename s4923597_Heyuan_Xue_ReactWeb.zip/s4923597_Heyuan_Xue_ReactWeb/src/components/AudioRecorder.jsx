import { useEffect, useRef, useState } from 'react'

export default function AudioRecorder({ onRecorded }) {
  const [supported, setSupported] = useState(true)
  const [state, setState] = useState('idle') // idle | recording | paused | done
  const mediaRef = useRef(null)
  const chunksRef = useRef([])

  useEffect(()=>{ if(!window.MediaRecorder) setSupported(false) }, [])

  const start = async () => {
    if(state !== 'idle') return
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
    const mr = new MediaRecorder(stream)
    chunksRef.current = []
    mr.ondataavailable = e => chunksRef.current.push(e.data)
    mr.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: 'audio/webm' })
      onRecorded?.(blob)
      stream.getTracks().forEach(t=>t.stop())
      setState('done') // ✅ 结束后锁死，禁止重录
    }
    mediaRef.current = mr
    mr.start()
    setState('recording')
  }

  const pause = () => { if(state==='recording'){ mediaRef.current?.pause(); setState('paused') } }
  const resume = () => { if(state==='paused'){ mediaRef.current?.resume(); setState('recording') } }
  const finish = () => { if(state==='recording'||state==='paused'){ mediaRef.current?.stop() } }

  if(!supported) return <div className="alert alert-warning">MediaRecorder not supported.</div>

  return (
    <div className="d-flex gap-2">
      <button className="btn btn-outline-primary" onClick={start} disabled={state!=='idle'}>Start</button>
      <button className="btn btn-outline-secondary" onClick={pause} disabled={state!=='recording'}>Pause</button>
      <button className="btn btn-outline-secondary" onClick={resume} disabled={state!=='paused'}>Resume</button>
      <button className="btn btn-outline-danger" onClick={finish} disabled={state==='idle'||state==='done'}>Finish</button>
      {state==='done' && <span className="badge bg-success align-self-center">Recorded & locked</span>}
    </div>
  )
}
