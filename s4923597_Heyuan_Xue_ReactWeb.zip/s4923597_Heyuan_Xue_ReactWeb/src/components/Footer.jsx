export default function Footer() {
    return (
      <footer className="text-center text-muted py-3" style={{borderTop:'1px solid #eee'}}>
        <small>© {new Date().getFullYear()} AI Interview Demo</small>
      </footer>
    );
  }
  