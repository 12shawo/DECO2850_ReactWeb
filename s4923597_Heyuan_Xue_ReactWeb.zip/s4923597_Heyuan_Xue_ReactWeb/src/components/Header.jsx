import { Link, NavLink } from 'react-router-dom'

export default function Header(){
  return (
    <nav className="navbar navbar-expand navbar-dark bg-dark px-3">
      <Link className="navbar-brand" to="/">AI Interview</Link>
      <div className="navbar-nav">
        <NavLink className="nav-link" to="/interviews">Interviews</NavLink>
        <NavLink className="nav-link" to="/questions">Questions</NavLink>
        <NavLink className="nav-link" to="/applicants">Applicants</NavLink>
        <NavLink className="nav-link" to="/take">Take Interview</NavLink>
      </div>
    </nav>
  )
}
