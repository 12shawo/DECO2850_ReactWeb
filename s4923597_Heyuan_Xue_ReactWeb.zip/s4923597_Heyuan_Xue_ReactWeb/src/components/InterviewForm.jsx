import { useEffect, useState } from 'react'

export default function InterviewForm({ onSubmit, initial }){
  const [title, setTitle] = useState('')
  const [jobRole, setJobRole] = useState('')
  const [description, setDescription] = useState('')
  const [status, setStatus] = useState('Draft')

  useEffect(()=>{
    setTitle(initial?.title || '')
    setJobRole(initial?.job_role || '')
    setDescription(initial?.description || '')
    setStatus(initial?.status || 'Draft')
  }, [initial])

  const submit = (e)=>{
    e.preventDefault()
    if(!title.trim()||!jobRole.trim()||!description.trim()||!status) return alert('All fields are required.')
    onSubmit({ title, job_role: jobRole, description, status })
    if(!initial){ setTitle(''); setJobRole(''); setDescription(''); setStatus('Draft') }
  }

  return (
    <form onSubmit={submit} className="card card-body mb-3">
      <div className="row g-3">
        <div className="col-md-6">
          <label className="form-label">Title*</label>
          <input className="form-control" value={title} onChange={e=>setTitle(e.target.value)} placeholder="Frontend Engineer Round 1" />
        </div>
        <div className="col-md-6">
          <label className="form-label">Job Role*</label>
          <input className="form-control" value={jobRole} onChange={e=>setJobRole(e.target.value)} placeholder="Frontend Engineer" />
        </div>
        <div className="col-12">
          <label className="form-label">Description*</label>
          <textarea className="form-control" rows="3" value={description} onChange={e=>setDescription(e.target.value)} placeholder="Short description"></textarea>
        </div>
        <div className="col-md-4">
          <label className="form-label">Status*</label>
          <select className="form-select" value={status} onChange={e=>setStatus(e.target.value)}>
            <option>Draft</option>
            <option>Published</option>
          </select>
        </div>
        <div className="col-12">
          <button className="btn btn-primary">{initial ? 'Update' : 'Add'}</button>
        </div>
      </div>
    </form>
  )
}
