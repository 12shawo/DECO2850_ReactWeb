export default function InterviewLink({ interviewId, applicantId }) {
  const base = window.location.origin
  const url = `${base}/take?interview=${encodeURIComponent(interviewId||'')}&applicant=${encodeURIComponent(applicantId||'')}`
  const copy = async () => {
    try { await navigator.clipboard.writeText(url); alert('Link copied!') }
    catch { alert('Copy failed, copy manually:\n' + url) }
  }
  return (
    <div className="input-group">
      <input className="form-control" value={url} readOnly />
      <button className="btn btn-outline-secondary" onClick={copy}>Copy</button>
    </div>
  )
}
