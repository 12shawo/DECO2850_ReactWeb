import { useEffect, useState } from 'react'

export default function QuestionForm({ onSubmit, initial, interviewId, setInterviewId }){
  const [question, setQuestion] = useState('')
  const [difficulty, setDifficulty] = useState('Easy')

  useEffect(()=>{
    setQuestion(initial?.question || '')
    setDifficulty(initial?.difficulty || 'Easy')
  }, [initial])

  const submit = (e)=>{
    e.preventDefault()
    if(!question.trim()||!difficulty) return alert('Question & Difficulty are required.')
    if(!interviewId) return alert('Please set Interview ID first.')
    onSubmit({ question, difficulty, interview_id: Number(interviewId) })
    if(!initial){ setQuestion(''); setDifficulty('Easy') }
  }

  return (
    <form onSubmit={submit} className="card card-body mb-3">
      <div className="row g-2">
        <div className="col-md-3">
          <label className="form-label">Interview ID*</label>
          <input
            className="form-control"
            value={interviewId ?? ''}
            onChange={e=>setInterviewId(e.target.value)}
            placeholder="e.g. 1"
          />
        </div>
        <div className="col-md-9">
          <label className="form-label">Question*</label>
          <input className="form-control" value={question} onChange={e=>setQuestion(e.target.value)} placeholder="Tell me about yourself." />
        </div>
        <div className="col-md-4">
          <label className="form-label">Difficulty*</label>
          <select className="form-select" value={difficulty} onChange={e=>setDifficulty(e.target.value)}>
            <option>Easy</option>
            <option>Intermediate</option>
            <option>Advanced</option>
          </select>
        </div>
        <div className="col-12">
          <button className="btn btn-primary">{initial ? 'Update' : 'Add'}</button>
        </div>
      </div>
    </form>
  )
}
