import { useEffect, useState } from 'react'
import { api } from '../services/api.js'
import ApplicantForm from '../components/ApplicantForm.jsx'
import InterviewLink from '../components/InterviewLink.jsx'

export default function ApplicantsPage(){
  const [items, setItems] = useState([])
  const [editing, setEditing] = useState(null)
  const [loading, setLoading] = useState(true)
  const [err, setErr] = useState('')
  const [answers, setAnswers] = useState(null) // {loading, rows, of}
  const [interviewId, setInterviewId] = useState('') // 过滤与创建
  const [deletingId, setDeletingId] = useState(null)

  const safe = async (fn) => { try { return await fn() } catch(e){ setErr(String(e?.message||e)); return null } }

  const refresh = async ()=>{
    setLoading(true); setErr('')
    const data = await safe(()=> api.getApplicants(interviewId || undefined))
    if (data) setItems(Array.isArray(data) ? data : (data?.data ?? []))
    setLoading(false)
  }
  useEffect(()=>{ refresh() }, [interviewId])

  const create = async (payload)=>{ const r=await safe(()=> api.createApplicant(payload)); if(!r) return; refresh() }
  const update = async (payload)=>{ const r=await safe(()=> api.updateApplicant(editing.id, payload)); if(!r) return; setEditing(null); refresh() }

  const removeItem = async (id)=>{
    if(!confirm('Delete this applicant?')) return
    setErr(''); setDeletingId(id)
    try{
      if (typeof api.deleteApplicant === 'function') await api.deleteApplicant(id)
      else if (typeof api.removeApplicant === 'function') await api.removeApplicant(id)
      else throw new Error('deleteApplicant/removeApplicant not implemented in api.js')
      await refresh()
    }catch(e){ setErr(String(e?.message||e)) }
    finally{ setDeletingId(null) }
  }

  const viewAnswers = async (applicant) => {
    setAnswers({ loading: true, rows: [], of: applicant })
    const r = await safe(()=> api.listAnswers(applicant.interview_id ?? interviewId, applicant.id))
    setAnswers({ loading:false, rows: (r && (r.data||r)) || [], of: applicant })
  }

  return (
    <div className="container py-3">
      <h2 className="mb-3">Applicants</h2>

      <ApplicantForm
        onSubmit={editing ? update : create}
        initial={editing || undefined}
        interviewId={interviewId}
        setInterviewId={setInterviewId}
      />

      {loading && <div className="alert alert-info">Loading…</div>}
      {!!err && <div className="alert alert-warning" style={{whiteSpace:'pre-wrap'}}>{err}</div>}

      {!loading && !err && (
        items.length ? (
          <div className="list-group">
            {items.map(a=>(
              <div key={a.id} className="list-group-item">
                <div className="d-flex justify-content-between align-items-center">
                  <div>
                    <div className="fw-semibold">{a.title} {a.firstname ?? a.first_name} {a.surname}</div>
                    <small className="text-muted">
                      {a.email_address ?? a.email} · {a.phone_number ?? a.phone} · {a.interview_status} · Interview #{a.interview_id}
                    </small>
                  </div>
                  <div className="btn-group">
                    <button type="button" className="btn btn-sm btn-outline-primary" onClick={()=>viewAnswers(a)}>View Answers</button>
                    <button type="button" className="btn btn-sm btn-outline-secondary" onClick={()=>setEditing(a)}>Edit</button>
                    <button
                      type="button"
                      className="btn btn-sm btn-outline-danger"
                      disabled={deletingId === a.id}
                      onClick={()=>removeItem(a.id)}
                    >
                      {deletingId === a.id ? 'Deleting…' : 'Delete'}
                    </button>
                  </div>
                </div>
                <div className="mt-2">
                  <InterviewLink interviewId={a.interview_id || interviewId} applicantId={a.id} />
                </div>
              </div>
            ))}
          </div>
        ) : <div className="alert alert-secondary">No applicants yet.</div>
      )}

      {answers && (
        <div className="card card-body mt-3">
          <div className="d-flex justify-content-between">
            <h5>Answers — {answers.of?.firstname ?? answers.of?.first_name} {answers.of?.surname}</h5>
            <button className="btn btn-sm btn-outline-secondary" onClick={()=>setAnswers(null)}>Close</button>
          </div>
          {answers.loading ? (
            <div className="alert alert-info mt-2">Loading answers…</div>
          ) : answers.rows.length ? (
            <ul className="list-group mt-2">
              {answers.rows.map((r,i)=>(
                <li key={r.id ?? i} className="list-group-item">
                  <div className="fw-semibold">Q#{r.question_id}</div>
                  <div className="mt-1">{r.answer ?? r.answer_text}</div>
                  <div className="small text-muted mt-1">{r.created_at}</div>
                </li>
              ))}
            </ul>
          ) : (
            <div className="alert alert-secondary mt-2">No answers.</div>
          )}
        </div>
      )}
    </div>
  )
}
