import { useEffect, useState } from 'react'
import { api } from '../services/api.js'
import InterviewForm from '../components/InterviewForm.jsx'
import InterviewLink from '../components/InterviewLink.jsx'

export default function InterviewsPage(){
  const [items, setItems] = useState([])
  const [editing, setEditing] = useState(null)
  const [loading, setLoading] = useState(true)
  const [err, setErr] = useState('')
  const [deletingId, setDeletingId] = useState(null)

  const safe = async (fn) => { try { return await fn() } catch(e){ setErr(String(e?.message||e)); return null } }

  const refresh = async ()=>{
    setLoading(true); setErr('')
    const data = await safe(()=> api.getInterviews())
    if (data) setItems(Array.isArray(data) ? data : (data?.data ?? []))
    setLoading(false)
  }
  useEffect(()=>{ refresh() }, [])

  const create = async (payload)=>{ const r=await safe(()=> api.createInterview(payload)); if(!r) return; refresh() }
  const update = async (payload)=>{ const r=await safe(()=> api.updateInterview(editing.id, payload)); if(!r) return; setEditing(null); refresh() }

  const removeItem = async (id)=>{
    if(!confirm('Delete this interview?')) return
    setErr(''); setDeletingId(id)
    try{
      if (typeof api.deleteInterview === 'function') await api.deleteInterview(id)
      else if (typeof api.removeInterview === 'function') await api.removeInterview(id)
      else throw new Error('deleteInterview/removeInterview not implemented in api.js')
      await refresh()
    }catch(e){ setErr(String(e?.message||e)) }
    finally{ setDeletingId(null) }
  }

  return (
    <div className="container py-3">
      <h2 className="mb-3">Interviews</h2>
      <InterviewForm onSubmit={editing ? update : create} initial={editing || undefined} />

      {loading && <div className="alert alert-info">Loading…</div>}
      {!!err && <div className="alert alert-warning" style={{whiteSpace:'pre-wrap'}}>{err}</div>}

      {!loading && !err && (
        items.length ? (
          <div className="list-group">
            {items.map(it=>(
              <div key={it.id} className="list-group-item">
                <div className="d-flex justify-content-between align-items-center">
                  <div>
                    <div className="fw-semibold">{it.title}</div>
                    <small className="text-muted">{it.job_role} · {it.status}</small>
                  </div>
                  <div className="btn-group">
                    <button type="button" className="btn btn-sm btn-outline-secondary" onClick={()=>setEditing(it)}>Edit</button>
                    <button
                      type="button"
                      className="btn btn-sm btn-outline-danger"
                      disabled={deletingId === it.id}
                      onClick={()=>removeItem(it.id)}
                    >
                      {deletingId === it.id ? 'Deleting…' : 'Delete'}
                    </button>
                  </div>
                </div>
                <div className="mt-2">
                  <InterviewLink interviewId={it.id} applicantId={''} />
                </div>
              </div>
            ))}
          </div>
        ) : <div className="alert alert-secondary">No interviews yet.</div>
      )}
    </div>
  )
}
