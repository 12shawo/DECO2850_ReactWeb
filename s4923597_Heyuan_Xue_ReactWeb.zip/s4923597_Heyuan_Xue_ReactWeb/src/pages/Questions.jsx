import { useEffect, useState } from 'react'
import { api } from '../services/api.js'
import QuestionForm from '../components/QuestionForm.jsx'

export default function QuestionsPage(){
  const [items, setItems] = useState([])
  const [editing, setEditing] = useState(null)
  const [loading, setLoading] = useState(true)
  const [err, setErr] = useState('')
  const [interviewId, setInterviewId] = useState('') // 用于过滤与创建
  const [deletingId, setDeletingId] = useState(null)

  const safe = async (fn) => { try { return await fn() } catch(e){ setErr(String(e?.message||e)); return null } }

  const refresh = async ()=>{
    setLoading(true); setErr('')
    const data = await safe(()=> api.getQuestions(interviewId || undefined))
    if (data) setItems(Array.isArray(data) ? data : (data?.data ?? []))
    setLoading(false)
  }
  useEffect(()=>{ refresh() }, [interviewId])

  const create = async (payload)=>{ const r=await safe(()=> api.createQuestion(payload)); if(!r) return; refresh() }
  const update = async (payload)=>{ const r=await safe(()=> api.updateQuestion(editing.id, payload)); if(!r) return; setEditing(null); refresh() }

  const removeItem = async (id)=>{
    if(!confirm('Delete this question?')) return
    setErr(''); setDeletingId(id)
    try{
      if (typeof api.deleteQuestion === 'function') await api.deleteQuestion(id)
      else if (typeof api.removeQuestion === 'function') await api.removeQuestion(id)
      else throw new Error('deleteQuestion/removeQuestion not implemented in api.js')
      await refresh()
    }catch(e){ setErr(String(e?.message||e)) }
    finally{ setDeletingId(null) }
  }

  return (
    <div className="container py-3">
      <h2 className="mb-3">Questions</h2>

      <QuestionForm
        onSubmit={editing ? update : create}
        initial={editing || undefined}
        interviewId={interviewId}
        setInterviewId={setInterviewId}
      />

      {loading && <div className="alert alert-info">Loading…</div>}
      {!!err && <div className="alert alert-warning" style={{whiteSpace:'pre-wrap'}}>{err}</div>}

      {!loading && !err && (
        items.length ? (
          <ul className="list-group">
            {items.map(q=>(
              <li key={q.id} className="list-group-item d-flex justify-content-between align-items-center">
                <div>
                  <div className="fw-semibold">{q.question ?? q.text ?? '(no question)'}</div>
                  <small className="text-muted">Interview #{q.interview_id} · {q.difficulty ?? '-'}</small>
                </div>
                <div className="btn-group">
                  <button type="button" className="btn btn-sm btn-outline-secondary" onClick={()=>setEditing(q)}>Edit</button>
                  <button
                    type="button"
                    className="btn btn-sm btn-outline-danger"
                    disabled={deletingId === q.id}
                    onClick={()=>removeItem(q.id)}
                  >
                    {deletingId === q.id ? 'Deleting…' : 'Delete'}
                  </button>
                </div>
              </li>
            ))}
          </ul>
        ) : <div className="alert alert-secondary">No questions yet.</div>
      )}
    </div>
  )
}
