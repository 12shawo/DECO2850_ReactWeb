import { useEffect, useMemo, useState } from 'react'
import { api } from '../services/api.js'
import AudioRecorder from '../components/AudioRecorder.jsx'

export default function TakeInterviewPage(){
  // 从 URL 读取初始值，但只有点击 Start 才真正开始
  const init = useMemo(() => new URLSearchParams(location.search), [])
  const [interviewId, setInterviewId] = useState(init.get('interview') || init.get('i') || '')
  const [applicantId, setApplicantId] = useState(init.get('applicant') || init.get('a') || '')

  // 是否已开始本次面试（Start 之后才为 true）
  const [started, setStarted] = useState(Boolean(init.get('interview') && init.get('applicant')))

  // 题目/进度
  const [questions, setQuestions] = useState([])
  const [idx, setIdx] = useState(0)
  const current = questions[idx]

  // 状态
  const [saving, setSaving] = useState(false)
  const [err, setErr] = useState('')
  const [done, setDone] = useState(false)
  const [currentSaved, setCurrentSaved] = useState(false) // 当前题是否已保存（Finish 后才为 true）
  const [loadingQuestions, setLoadingQuestions] = useState(false)

  const safe = async (fn) => { try { return await fn() } catch(e){ setErr(String(e?.message||e)); return null } }

  // 按 interviewId 拉题（开始后再拉）
  useEffect(()=>{
    if (!started || !interviewId) return
    ;(async ()=>{
      setLoadingQuestions(true); setErr('')
      const data = await safe(()=> api.getQuestions(Number(interviewId)))
      if (data) {
        const arr = Array.isArray(data) ? data : (data?.data ?? [])
        setQuestions(arr)
        setIdx(0)
        setCurrentSaved(false)
      }
      setLoadingQuestions(false)
    })()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [started, interviewId])

  // 把 ID 写回 URL（不刷新页面），仅在 Start 时做
  const writeIdsToUrl = ()=>{
    const sp = new URLSearchParams(location.search)
    if (interviewId) sp.set('interview', interviewId)
    if (applicantId) sp.set('applicant', applicantId)
    const newUrl = `${location.pathname}?${sp.toString()}`
    history.replaceState(null, '', newUrl)
  }

  // 占位“转写”——不做真实推理，仅生成一段文本
  async function fakeTranscribe(blob){
    const secs = Math.max(1, Math.round(blob.size/16000))
    return `Transcribed text (placeholder) — ~${secs}s`
  }

  // 录音完成（Finish）后保存当前题答案 —— 不自动跳题，等用户点 Next/Finish Interview
  async function onRecorded(blob){
    if(!current || !applicantId){ alert('Missing applicant or question.'); return }
    setSaving(true); setErr('')
    try{
      const text = await fakeTranscribe(blob)
      const saver = ['saveAnswer','createAnswer','postAnswer'].find(n => typeof api[n]==='function')
      if (saver){
        const r = await safe(()=> api[saver]({
          interview_id: Number(interviewId) || interviewId,
          applicant_id: Number(applicantId) || applicantId,
          question_id: current.id,
          answer_text: text, // api.js 会规范化为 answer 字段
        }))
        if (!r) return
      } else {
        alert('answers API 未提供（占位）。录音文本未真正保存到后端。')
      }
      setCurrentSaved(true) // 这题已保存，显示 Next/Finish 按钮
    } finally {
      setSaving(false)
    }
  }

  // 结束整场面试
  const finishInterview = async ()=>{
    const upd = ['updateApplicant','patchApplicant'].find(n => typeof api[n]==='function')
    if (upd) await safe(()=> api[upd](applicantId, { interview_status:'Completed' }))
    setDone(true)
  }

  // 重新开始：清空 started & 进度，并（可选）清理 URL
  const restart = ()=>{
    setStarted(false)
    setIdx(0)
    setCurrentSaved(false)
    setErr('')
    const sp = new URLSearchParams(location.search)
    sp.delete('interview'); sp.delete('applicant')
    history.replaceState(null, '', `${location.pathname}`)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  // 已完成画面
  if(done){
    return (
      <div className="container py-5">
        <div className="card card-body text-center">
          <h3 className="mb-3">Thanks for completing the interview!</h3>
          <p className="text-muted">Your responses have been recorded.</p>
          <button type="button" className="btn btn-outline-secondary mt-2" onClick={restart}>Restart</button>
        </div>
      </div>
    )
  }

  const canStart = Boolean(interviewId) && Boolean(applicantId)
  const isLast = idx >= 0 && idx === (questions.length - 1)

  return (
    <div className="container py-3">
      <h2 className="mb-3">Take Interview</h2>

      {/* 顶部输入卡：只在还没 start 时出现；输入框始终可编辑 */}
      {!started && (
        <div className="card card-body mb-3">
          <div className="row g-2">
            <div className="col-md-4">
              <label className="form-label">Interview ID</label>
              <input className="form-control" value={interviewId} onChange={(e)=>setInterviewId(e.target.value)} placeholder="e.g. 1" />
            </div>
            <div className="col-md-4">
              <label className="form-label">Applicant ID</label>
              <input className="form-control" value={applicantId} onChange={(e)=>setApplicantId(e.target.value)} placeholder="e.g. 2" />
            </div>
            <div className="col-md-4 d-flex align-items-end">
              <button
                type="button"
                className="btn btn-primary w-100"
                disabled={!canStart}
                onClick={()=>{
                  if (!canStart) return
                  writeIdsToUrl()
                  setStarted(true)
                  setIdx(0)
                  setCurrentSaved(false)
                  window.scrollTo({ top: 0, behavior: 'smooth' })
                }}
                title={canStart ? '' : 'Please fill both IDs'}
              >
                Start Interview
              </button>
            </div>
          </div>
          <div className="small text-muted mt-2">
            （也可以直接访问 <code>/take?interview=1&amp;applicant=2</code>）
          </div>
        </div>
      )}

      {/* 已开始时显示当前会话信息 + Restart */}
      {started && (
        <div className="d-flex align-items-center gap-2 mb-2">
          <span className="badge text-bg-secondary">Interview #{interviewId}</span>
          <span className="badge text-bg-secondary">Applicant #{applicantId}</span>
          <button type="button" className="btn btn-sm btn-outline-secondary ms-auto" onClick={restart}>Restart</button>
        </div>
      )}

      {!!err && <div className="alert alert-danger" style={{whiteSpace:'pre-wrap'}}>{err}</div>}

      {/* 主卡片：题目 + 录音 + 控制 */}
      <div className="card card-body">
        <div className="d-flex justify-content-between align-items-center">
          <div className="fw-semibold">
            {loadingQuestions ? 'Loading questions…' : `Question ${questions.length ? (idx+1) : 0} / ${questions.length}`}
          </div>
        </div>

        <div className="mt-2 p-3 bg-light rounded" style={{minHeight:80}}>
          {current ? (current.question ?? current.text ?? '(no question)') : (loadingQuestions ? 'Loading…' : 'No questions')}
        </div>

        <div className="mt-3">
          {/* 关键：不同题目给不同 key，切题强制重挂载录音组件，Start/Finish 状态不会互相影响 */}
          <AudioRecorder key={current ? `q-${current.id ?? idx}` : `q-${idx}`} onRecorded={onRecorded} />
          {saving && <div className="mt-2 alert alert-info">Saving answer…</div>}
          <div className="small text-muted mt-2">Finish = end this question’s recording (locked). Then proceed below.</div>
        </div>

        {/* 每题保存成功后出现操作按钮：Next / Finish Interview */}
        <div className="mt-3 d-flex gap-2">
          {!currentSaved && <div className="text-muted small">Record &amp; Finish to proceed.</div>}

          {currentSaved && !isLast && (
            <button
              type="button"
              className="btn btn-primary"
              onClick={()=>{
                setIdx(i => Math.min(i + 1, questions.length - 1))
                setCurrentSaved(false) // 切到下一题时清掉“已保存”标记
                window.scrollTo({ top: 0, behavior: 'smooth' })
              }}
            >
              Next question
            </button>
          )}

          {currentSaved && isLast && (
            <button
              type="button"
              className="btn btn-success"
              onClick={finishInterview}
            >
              Finish Interview
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
