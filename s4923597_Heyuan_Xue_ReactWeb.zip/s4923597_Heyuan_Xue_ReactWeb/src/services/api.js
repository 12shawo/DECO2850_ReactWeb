// src/services/api.js  —— 修复 400（字段映射 + 默认 interview_id + select=*）

const API_BASE =
  (import.meta.env && import.meta.env.VITE_API_BASE_URL) ||
  '/api'; // 开发期若用 Vite 代理，就保留 /api；否则改成完整 https://comp2140a2.uqcloud.net/api

const API_KEY =
  (import.meta.env && import.meta.env.VITE_API_KEY) || '';

const EXPLICIT_USERNAME =
  (import.meta.env && import.meta.env.VITE_USERNAME) || '';

const DEFAULT_INTERVIEW_ID =
  (import.meta.env && import.meta.env.VITE_DEFAULT_INTERVIEW_ID) || ''; // 可在 .env 配置，例如 1

function usernameFromJWT(token) {
  try {
    const seg = token.split('.')[1];
    if (!seg) return '';
    const json = JSON.parse(atob(seg.replace(/-/g, '+').replace(/_/g, '/')));
    return (json && (json.username || json.user || json.name)) || '';
  } catch { return ''; }
}
const DEFAULT_USERNAME = EXPLICIT_USERNAME || usernameFromJWT(API_KEY) || '';

function baseHeaders(extra = {}) {
  const h = { 'Content-Type': 'application/json', ...extra };
  if (API_KEY) { h.Authorization = `Bearer ${API_KEY}`; h.apikey = API_KEY; }
  return h;
}

async function request(path, { method='GET', body, headers } = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers: baseHeaders(headers),
    body: body ? JSON.stringify(body) : undefined,
    credentials: 'omit',
    redirect: 'follow',
  });
  const ct = res.headers.get('content-type') || '';
  const isJson = ct.includes('application/json');
  const data = isJson ? await res.json().catch(()=>null) : await res.text();
  if (!res.ok) {
    const msg =
      (data && typeof data === 'object' && (data.message || data.hint || JSON.stringify(data))) ||
      (typeof data === 'string' && data.slice(0,300)) || res.statusText;
    throw new Error(`HTTP ${res.status} — ${msg}`);
  }
  return data;
}

const q = encodeURIComponent;
const list = (table, qs='') => `/${table}${qs?`?${qs}`:''}`;
const byId = (table, id) => `/${table}?id=eq.${q(id)}`;

const T = {
  interviews: 'interview',
  questions:  'question',
  applicants: 'applicant',
  answers:    'applicant_answer',
};

/* ------------------ 规范化：把表单字段映射为后端字段 ------------------ */
function normInterview(p={}) {
  const out = {
    title: p.title ?? '',
    job_role: p.job_role ?? p.jobRole ?? '',
    description: p.description ?? '',
    status: p.status ?? 'Draft',
    username: p.username ?? DEFAULT_USERNAME
  };
  return out;
}

function normQuestion(p={}) {
  const out = {
    question: p.question ?? p.text ?? '',
    difficulty: p.difficulty ?? 'Easy',
    interview_id: (p.interview_id ?? p.interviewId ?? DEFAULT_INTERVIEW_ID) || null,
    username: p.username ?? DEFAULT_USERNAME
  };
  // 如果仍然没有 interview_id，去掉该字段（后端若允许空就通过；若必须则返回 400，需要你提供）
  if (!out.interview_id) delete out.interview_id;
  return out;
}

function normApplicant(p={}) {
  const out = {
    title: p.title ?? '',
    firstname: p.firstname ?? p.first_name ?? '',
    surname: p.surname ?? '',
    phone_number: p.phone_number ?? p.phone ?? '',
    email_address: p.email_address ?? p.email ?? '',
    interview_status: p.interview_status ?? 'Not Started',
    interview_id: (p.interview_id ?? p.interviewId ?? DEFAULT_INTERVIEW_ID) || null,
    username: p.username ?? DEFAULT_USERNAME
  };
  if (!out.interview_id) delete out.interview_id;
  return out;
}

function normAnswer(p={}) {
  const { answer_text, answer, ...rest } = p;
  return {
    answer: answer_text != null ? answer_text : (answer ?? ''),
    username: p.username ?? DEFAULT_USERNAME,
    ...rest
  };
}

/* ------------------ Interviews ------------------ */
async function getInterviews() {
  return request(list(T.interviews, 'select=*&order=id.desc'));
}
async function createInterview(payload) {
  return request(list(T.interviews), {
    method: 'POST',
    body: normInterview(payload),
    headers: { Prefer: 'return=representation' }
  });
}
async function updateInterview(id, payload) {
  return request(byId(T.interviews, id), {
    method: 'PATCH',
    body: normInterview(payload),
    headers: { Prefer: 'return=representation' }
  });
}
async function deleteInterview(id) {
  return request(byId(T.interviews, id), { method: 'DELETE' });
}

/* ------------------ Questions ------------------ */
async function getQuestions(interviewId) {
  const qs = interviewId
    ? `select=*&interview_id=eq.${q(interviewId)}&order=id.desc`
    : `select=*&order=id.desc`;
  return request(list(T.questions, qs));
}
async function createQuestion(payload) {
  return request(list(T.questions), {
    method: 'POST',
    body: normQuestion(payload),
    headers: { Prefer: 'return=representation' }
  });
}
async function updateQuestion(id, payload) {
  return request(byId(T.questions, id), {
    method: 'PATCH',
    body: normQuestion(payload),
    headers: { Prefer: 'return=representation' }
  });
}
async function deleteQuestion(id) {
  return request(byId(T.questions, id), { method: 'DELETE' });
}

/* ------------------ Applicants ------------------ */
async function getApplicants(interviewId) {
  const qs = interviewId
    ? `select=*&interview_id=eq.${q(interviewId)}&order=id.desc`
    : `select=*&order=id.desc`;
  return request(list(T.applicants, qs));
}
async function createApplicant(payload) {
  return request(list(T.applicants), {
    method: 'POST',
    body: normApplicant(payload),
    headers: { Prefer: 'return=representation' }
  });
}
async function updateApplicant(id, payload) {
  return request(byId(T.applicants, id), {
    method: 'PATCH',
    body: normApplicant(payload),
    headers: { Prefer: 'return=representation' }
  });
}
async function deleteApplicant(id) {
  return request(byId(T.applicants, id), { method: 'DELETE' });
}

/* ------------------ Answers ------------------ */
async function listAnswers(interviewId, applicantId) {
  let qs = `select=*&applicant_id=eq.${q(applicantId)}&order=question_id.asc`;
  if (interviewId) qs = `select=*&interview_id=eq.${q(interviewId)}&applicant_id=eq.${q(applicantId)}&order=question_id.asc`;
  return request(list(T.answers, qs));
}
async function saveAnswer(payload) {
  return request(list(T.answers), {
    method: 'POST',
    body: normAnswer(payload),
    headers: { Prefer: 'return=representation' }
  });
}
async function updateAnswer(id, payload) {
  return request(byId(T.answers, id), {
    method: 'PATCH',
    body: normAnswer(payload),
    headers: { Prefer: 'return=representation' }
  });
}
async function deleteAnswer(id) {
  return request(byId(T.answers, id), { method: 'DELETE' });
}

export const api = {
  // Interviews
  getInterviews, createInterview, updateInterview, deleteInterview,
  // Questions
  getQuestions, createQuestion, updateQuestion, deleteQuestion,
  // Applicants
  getApplicants, createApplicant, updateApplicant, deleteApplicant,
  // Answers
  listAnswers, saveAnswer, updateAnswer, deleteAnswer,
};
